import Foundation
import CoreBluetooth

/// Best-effort brand detection from the BLE advertised name, so the scanner can
/// show a recognizable icon/color even for scooters we don't have a protocol for
/// yet. This is a heuristic (string matching), not a guarantee.
enum ScooterBrand: String, CaseIterable {
    case kukirin, xiaomi, ninebot, segway, kugoo, iscooter, inokim, unknown

    static func detect(fromName name: String) -> ScooterBrand {
        let n = name.lowercased()
        if n.contains("kukirin") || n.contains("kk-") { return .kukirin }
        if n.contains("ninebot") { return .ninebot }
        if n.contains("segway") { return .segway }
        if n.contains("xiaomi") || n.contains("mi ") || n.contains("m365") || n.contains("mibody") || n.contains("miscooter") { return .xiaomi }
        if n.contains("kugoo") { return .kugoo }
        if n.contains("iscooter") { return .iscooter }
        if n.contains("inokim") { return .inokim }
        return .unknown
    }

    var displayName: String {
        switch self {
        case .kukirin: return "Kukirin"
        case .xiaomi: return "Xiaomi / Mi"
        case .ninebot: return "Ninebot"
        case .segway: return "Segway"
        case .kugoo: return "Kugoo"
        case .iscooter: return "iScooter"
        case .inokim: return "Inokim"
        case .unknown: return "Unknown device"
        }
    }

    /// SF Symbol used as a stand-in "picture". We deliberately don't bundle real
    /// manufacturer product photos/logos (trademarked, and I can't verify
    /// licensing on scraped images) - this keeps things safe to ship while still
    /// giving each brand its own recognizable look.
    var symbolName: String {
        switch self {
        case .kukirin: return "bolt.car.fill"
        case .xiaomi: return "scooter"
        case .ninebot: return "figure.outdoor.cycle"
        case .segway: return "gyroscope"
        case .kugoo: return "scooter"
        case .iscooter: return "scooter"
        case .inokim: return "scooter"
        case .unknown: return "questionmark.circle"
        }
    }

    var tint: (Double, Double, Double) { // r, g, b 0-1, used to build a Color without importing SwiftUI here
        switch self {
        case .kukirin: return (0.29, 0.85, 0.24)
        case .xiaomi: return (1.00, 0.52, 0.0)
        case .ninebot: return (0.16, 0.75, 0.95)
        case .segway: return (0.55, 0.35, 0.95)
        case .kugoo: return (0.90, 0.30, 0.55)
        case .iscooter: return (0.95, 0.75, 0.15)
        case .inokim: return (0.35, 0.65, 0.95)
        case .unknown: return (0.55, 0.58, 0.62)
        }
    }
}

enum RideMode: Int, CaseIterable, Identifiable, Codable {
    case eco = 0
    case drive = 1
    case sport = 2

    var id: Int { rawValue }

    var title: String {
        switch self {
        case .eco: return "Eco"
        case .drive: return "Drive"
        case .sport: return "Sport"
        }
    }

    var symbol: String {
        switch self {
        case .eco: return "leaf.fill"
        case .drive: return "gauge.medium"
        case .sport: return "bolt.fill"
        }
    }

    /// Hard ceiling the slider for this mode can't exceed (km/h).
    /// Adjust to match your scooter model's real limits.
    var absoluteMaxKmh: Double {
        switch self {
        case .eco: return 15
        case .drive: return 25
        case .sport: return 45
        }
    }
}

/// Live telemetry snapshot from the scooter.
struct ScooterTelemetry: Codable, Equatable {
    var speedKmh: Double = 0
    var batteryPercent: Int = 0
    var voltage: Double = 0
    var odometerKm: Double = 0
    var tripKm: Double = 0
    var mode: RideMode = .drive
    var isLocked: Bool = false
    var lightsOn: Bool = false
    var cruiseControlOn: Bool = false
    var errorCode: Int? = nil
}

/// Per-mode configurable max speed, mirrors the settings screen in Kukirin's own app.
struct ModeSpeedLimits: Codable, Equatable {
    var eco: Double = 12
    var drive: Double = 20
    var sport: Double = 40

    func value(for mode: RideMode) -> Double {
        switch mode {
        case .eco: return eco
        case .drive: return drive
        case .sport: return sport
        }
    }

    mutating func setValue(_ value: Double, for mode: RideMode) {
        switch mode {
        case .eco: eco = value
        case .drive: drive = value
        case .sport: sport = value
        }
    }
}

/// A discovered / connected scooter.
final class Scooter: Identifiable, ObservableObject, Equatable {
    let id: UUID
    let peripheral: CBPeripheral?
    @Published var name: String
    @Published var rssi: Int
    @Published var telemetry = ScooterTelemetry()
    @Published var limits = ModeSpeedLimits()
    @Published var connectionState: ConnectionState = .disconnected
    let isDemo: Bool

    var brand: ScooterBrand { ScooterBrand.detect(fromName: name) }

    enum ConnectionState: Equatable {
        case disconnected
        case connecting
        case connected
        case failed(String)
    }

    init(peripheral: CBPeripheral?, name: String, rssi: Int, isDemo: Bool = false) {
        self.id = peripheral?.identifier ?? UUID()
        self.peripheral = peripheral
        self.name = name
        self.rssi = rssi
        self.isDemo = isDemo
    }

    static func == (lhs: Scooter, rhs: Scooter) -> Bool {
        lhs.id == rhs.id
    }
}
