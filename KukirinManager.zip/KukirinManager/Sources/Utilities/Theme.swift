import SwiftUI

/// Central place for colors / gradients so every screen looks consistent.
enum Theme {
    static let background = Color(red: 0.06, green: 0.07, blue: 0.09)
    static let cardBackground = Color(red: 0.11, green: 0.12, blue: 0.15)
    static let cardBackgroundLight = Color(red: 0.15, green: 0.16, blue: 0.20)
    static let accent = Color(red: 0.29, green: 0.85, blue: 0.24)      // electric green
    static let accentSecondary = Color(red: 0.16, green: 0.75, blue: 0.95) // cyan
    static let warning = Color(red: 0.98, green: 0.65, blue: 0.14)
    static let danger = Color(red: 0.93, green: 0.27, blue: 0.27)
    static let textPrimary = Color.white
    static let textSecondary = Color.white.opacity(0.6)

    static let backgroundGradient = LinearGradient(
        colors: [Color(red: 0.05, green: 0.06, blue: 0.08), Color(red: 0.09, green: 0.10, blue: 0.13)],
        startPoint: .top, endPoint: .bottom
    )

    static let accentGradient = LinearGradient(
        colors: [accent, accentSecondary],
        startPoint: .leading, endPoint: .trailing
    )
}

struct CardBackground: ViewModifier {
    func body(content: Content) -> some View {
        content
            .padding(16)
            .background(
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .fill(Theme.cardBackground)
            )
    }
}

extension View {
    func cardStyle() -> some View { modifier(CardBackground()) }
}
