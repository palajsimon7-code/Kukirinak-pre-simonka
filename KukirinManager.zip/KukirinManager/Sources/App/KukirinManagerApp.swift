import SwiftUI

@main
struct KukirinManagerApp: App {

    @StateObject private var bleManager = BLEManager()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(bleManager)
                .preferredColorScheme(.dark)
        }
    }
}
