import Foundation
import CoreBluetooth
import Combine

final class BLEManager: NSObject, ObservableObject {

    @Published var isBluetoothOn: Bool = false
    @Published var isScanning: Bool = false
    @Published var discovered: [Scooter] = []
    @Published var connected: Scooter? = nil
    @Published var demoModeEnabled: Bool = false

    /// Services/characteristics discovered on the connected peripheral, refreshed
    /// live so the Custom Command screen can list them for you to explore/send to.
    @Published var connectedServices: [CBService] = []

    /// Rolling log of everything sent/received over BLE - useful both as a raw
    /// command console and as a lightweight in-app packet sniffer while you're
    /// reverse engineering your own scooter's protocol.
    @Published var log: [BLELogEntry] = []

    private var central: CBCentralManager!
    private var commandCharacteristic: CBCharacteristic?
    private var demoTimer: Timer?
    private var demoDirection: Double = 1
    private let maxLogEntries = 300

    override init() {
        super.init()
        central = CBCentralManager(delegate: self, queue: .main)
        #if targetEnvironment(simulator)
        // CoreBluetooth doesn't work in the simulator - default to demo mode there.
        demoModeEnabled = true
        #endif
    }

    // MARK: - Scanning

    /// Scans for ANY nearby BLE peripheral (no service/name filter), so scooters
    /// from Kukirin, Xiaomi/Ninebot, Segway, Kugoo, etc. - or anything else - all
    /// show up. `Scooter.brand` does best-effort name matching afterwards purely
    /// to pick an icon/color; it never excludes a device from the list.
    func startScan() {
        guard !demoModeEnabled else { return }
        guard central.state == .poweredOn else { return }
        discovered.removeAll()
        isScanning = true
        central.scanForPeripherals(withServices: nil, options: [
            CBCentralManagerScanOptionAllowDuplicatesKey: true
        ])
    }

    func stopScan() {
        isScanning = false
        central.stopScan()
    }

    // MARK: - Connect / disconnect

    func connect(_ scooter: Scooter) {
        if scooter.isDemo || demoModeEnabled {
            connectDemo(scooter)
            return
        }
        guard let peripheral = scooter.peripheral else { return }
        stopScan()
        scooter.connectionState = .connecting
        connected = scooter
        central.connect(peripheral, options: nil)
    }

    func disconnect() {
        guard let scooter = connected else { return }
        stopDemoTimer()
        if let peripheral = scooter.peripheral, !scooter.isDemo {
            central.cancelPeripheralConnection(peripheral)
        }
        scooter.connectionState = .disconnected
        connected = nil
        commandCharacteristic = nil
        connectedServices = []
    }

    // MARK: - Demo mode

    func makeDemoScooter() -> Scooter {
        Scooter(peripheral: nil, name: "Kukirin G2 Max (Demo)", rssi: -45, isDemo: true)
    }

    private func connectDemo(_ scooter: Scooter) {
        scooter.connectionState = .connecting
        connected = scooter
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) { [weak self] in
            guard let self, self.connected === scooter else { return }
            scooter.connectionState = .connected
            scooter.telemetry.batteryPercent = 82
            scooter.telemetry.odometerKm = 214.3
            scooter.telemetry.mode = .drive
            self.startDemoTimer(for: scooter)
        }
    }

    private func startDemoTimer(for scooter: Scooter) {
        stopDemoTimer()
        demoTimer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { [weak self] _ in
            guard let self, let scooter = self.connected else { return }
            var t = scooter.telemetry
            let maxForMode = scooter.limits.value(for: t.mode)
            t.speedKmh += Double.random(in: -1.5...1.8) * self.demoDirection
            t.speedKmh = max(0, min(t.speedKmh, maxForMode))
            if t.speedKmh <= 0 || t.speedKmh >= maxForMode { self.demoDirection *= -1 }
            t.tripKm += t.speedKmh * (0.5 / 3600.0)
            t.odometerKm += t.speedKmh * (0.5 / 3600.0)
            if Int(Date().timeIntervalSince1970) % 20 == 0 {
                t.batteryPercent = max(0, t.batteryPercent - (Bool.random() ? 1 : 0))
            }
            scooter.telemetry = t
        }
    }

    private func stopDemoTimer() {
        demoTimer?.invalidate()
        demoTimer = nil
    }

    // MARK: - Sending commands

    func setMode(_ mode: RideMode) {
        guard let scooter = connected else { return }
        scooter.telemetry.mode = mode
        if scooter.isDemo || demoModeEnabled { return }
        write(ScooterProtocol.encodeSetMode(mode))
    }

    func setMaxSpeed(_ kmh: Double, for mode: RideMode) {
        guard let scooter = connected else { return }
        scooter.limits.setValue(kmh, for: mode)
        if scooter.isDemo || demoModeEnabled { return }
        write(ScooterProtocol.encodeSetMaxSpeed(kmh, for: mode))
    }

    func setLocked(_ locked: Bool) {
        guard let scooter = connected else { return }
        scooter.telemetry.isLocked = locked
        if scooter.isDemo || demoModeEnabled { return }
        write(ScooterProtocol.encodeSetLock(locked))
    }

    func setLights(_ on: Bool) {
        guard let scooter = connected else { return }
        scooter.telemetry.lightsOn = on
        if scooter.isDemo || demoModeEnabled { return }
        write(ScooterProtocol.encodeSetLights(on))
    }

    func setCruiseControl(_ on: Bool) {
        guard let scooter = connected else { return }
        scooter.telemetry.cruiseControlOn = on
        if scooter.isDemo || demoModeEnabled { return }
        write(ScooterProtocol.encodeSetCruiseControl(on))
    }

    private func write(_ data: Data) {
        guard let peripheral = connected?.peripheral, let characteristic = commandCharacteristic else { return }
        let type: CBCharacteristicWriteType = characteristic.properties.contains(.writeWithoutResponse) ? .withoutResponse : .withResponse
        peripheral.writeValue(data, for: characteristic, type: type)
        appendLog(direction: .sent, characteristic: characteristic, data: data)
    }

    // MARK: - Raw / custom commands (Custom Command screen)

    /// Subscribes to notifications on an arbitrary characteristic, so you can
    /// watch what a service sends back while probing it.
    func subscribe(to characteristic: CBCharacteristic) {
        guard let peripheral = connected?.peripheral, !isDemoConnection else { return }
        peripheral.setNotifyValue(true, for: characteristic)
    }

    /// Sends raw bytes (from a hex string like "AA 01 02" or "AA0102") to any
    /// writable characteristic on the connected device. This is the generic
    /// "BLE terminal" used by the Custom Command screen, independent of whatever
    /// is in ScooterProtocol.swift - handy both for driving a scooter once you
    /// know its command bytes, and for probing/reverse engineering one you don't.
    @discardableResult
    func sendRawCommand(hex: String, to characteristic: CBCharacteristic) -> Bool {
        guard let peripheral = connected?.peripheral, !isDemoConnection else { return false }
        guard let data = Data(hexString: hex), !data.isEmpty else { return false }
        let type: CBCharacteristicWriteType = characteristic.properties.contains(.writeWithoutResponse) ? .withoutResponse : .withResponse
        peripheral.writeValue(data, for: characteristic, type: type)
        appendLog(direction: .sent, characteristic: characteristic, data: data)
        return true
    }

    private var isDemoConnection: Bool { connected?.isDemo ?? false }

    private func appendLog(direction: BLELogEntry.Direction, characteristic: CBCharacteristic, data: Data) {
        let entry = BLELogEntry(
            timestamp: Date(),
            characteristicUUID: characteristic.uuid.uuidString,
            direction: direction,
            hex: data.hexString
        )
        log.append(entry)
        if log.count > maxLogEntries { log.removeFirst(log.count - maxLogEntries) }
    }
}

/// One line of the BLE command/notification log shown in the Custom Command screen.
struct BLELogEntry: Identifiable, Equatable {
    enum Direction: String { case sent = "SENT", received = "RECV" }
    let id = UUID()
    let timestamp: Date
    let characteristicUUID: String
    let direction: Direction
    let hex: String
}

extension Data {
    /// Parses hex like "AA 01 02", "AA-01-02", "0xAA 0x01", or "AA0102" into bytes.
    init?(hexString: String) {
        let cleaned = hexString
            .replacingOccurrences(of: "0x", with: "")
            .replacingOccurrences(of: "0X", with: "")
            .filter { $0.isHexDigit }
        guard !cleaned.isEmpty, cleaned.count % 2 == 0 else { return nil }
        var bytes = [UInt8]()
        var index = cleaned.startIndex
        while index < cleaned.endIndex {
            let next = cleaned.index(index, offsetBy: 2)
            guard let byte = UInt8(cleaned[index..<next], radix: 16) else { return nil }
            bytes.append(byte)
            index = next
        }
        self = Data(bytes)
    }

    var hexString: String {
        map { String(format: "%02X", $0) }.joined(separator: " ")
    }
}

// MARK: - CBCentralManagerDelegate

extension BLEManager: CBCentralManagerDelegate {

    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        isBluetoothOn = (central.state == .poweredOn)
        if central.state != .poweredOn {
            isScanning = false
        }
    }

    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String: Any], rssi RSSI: NSNumber) {
        let name = peripheral.name
            ?? (advertisementData[CBAdvertisementDataLocalNameKey] as? String)
            ?? "Unknown device"

        if let existing = discovered.first(where: { $0.peripheral?.identifier == peripheral.identifier }) {
            existing.rssi = RSSI.intValue
            existing.name = name
            return
        }
        let scooter = Scooter(peripheral: peripheral, name: name, rssi: RSSI.intValue)
        discovered.append(scooter)
        discovered.sort { $0.rssi > $1.rssi }
    }

    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        peripheral.delegate = self
        peripheral.discoverServices(nil)
    }

    func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
        connected?.connectionState = .failed(error?.localizedDescription ?? "Failed to connect")
    }

    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        connected?.connectionState = .disconnected
        connected = nil
        commandCharacteristic = nil
    }
}

// MARK: - CBPeripheralDelegate

extension BLEManager: CBPeripheralDelegate {

    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        peripheral.services?.forEach { peripheral.discoverCharacteristics(nil, for: $0) }
    }

    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        guard let characteristics = service.characteristics else { return }
        for characteristic in characteristics {
            if characteristic.uuid == ScooterProtocol.commandCharacteristicUUID {
                commandCharacteristic = characteristic
            }
            if characteristic.uuid == ScooterProtocol.telemetryCharacteristicUUID || characteristic.properties.contains(.notify) {
                peripheral.setNotifyValue(true, for: characteristic)
            }
        }
        // As soon as we've discovered something usable, mark connected.
        if connected?.connectionState != .connected {
            connected?.connectionState = .connected
        }
        connectedServices = peripheral.services ?? []
    }

    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        guard let data = characteristic.value, let scooter = connected else { return }

        // Always log the raw bytes, regardless of whether we can decode them -
        // this is what makes the Custom Command screen useful for reverse
        // engineering: press a button in the *official* app, watch what shows
        // up here on whichever characteristic lit up.
        appendLog(direction: .received, characteristic: characteristic, data: data)

        if let updated = ScooterProtocol.decodeTelemetry(data, previous: scooter.telemetry) {
            scooter.telemetry = updated
        }
    }

    func peripheral(_ peripheral: CBPeripheral, didWriteValueFor characteristic: CBCharacteristic, error: Error?) {
        // Hook for confirming a command was accepted, if your scooter ACKs writes.
    }
}
