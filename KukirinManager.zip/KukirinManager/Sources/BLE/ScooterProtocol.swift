import Foundation
import CoreBluetooth

/// ============================================================================
///  ⚠️  THIS FILE IS A TEMPLATE — NOT THE REAL KUKIRIN PROTOCOL  ⚠️
/// ============================================================================
///
/// Kukirin does not publish their BLE GATT protocol, and I (the assistant that
/// generated this project) do not have access to the real service UUIDs,
/// characteristic UUIDs, or command byte layout used by the official
/// "Kukirin Manager" app. Nobody can invent these correctly - they have to be
/// captured from a real scooter + the real app. Any code claiming to already
/// know them would just silently fail to control your scooter.
///
/// The good news: capturing them yourself is a well-known, ~15 minute process:
///
///   1. On an Android phone, enable Developer Options -> "Bluetooth HCI snoop
///      log" (or use an iOS PacketLogger via Xcode's Additional Tools for
///      Xcode -> Hardware -> Bluetooth, with a Mac + the official Kukirin app).
///   2. Open the real Kukirin Manager app, connect to your scooter, and tap
///      through every action: change mode, change max speed per mode, toggle
///      lights, lock/unlock.
///   3. Pull the resulting log (Android: /sdcard/btsnoop_hci.log, or
///      Wireshark can capture the Apple PacketLogger stream directly) and
///      open it in Wireshark. Filter on "btatt" to see only GATT
///      reads/writes/notifications.
///   4. For each button you tapped, find the corresponding "Write Request"
///      or "Handle Value Notification" packet. Note:
///        - The service UUID and characteristic UUID being written to / read from
///        - The exact bytes sent for each action (they usually differ by only
///          1-2 bytes between e.g. Eco vs Drive vs Sport)
///        - The bytes of the periodic telemetry notification (speed, battery,
///          etc. are usually packed at fixed byte offsets, sometimes little-
///          endian 16-bit values, sometimes with a simple checksum byte)
///   5. Fill in the constants and `encode` / `decode` functions below.
///
/// Everything else in this app (scanning, connecting, the whole UI, demo mode)
/// is fully functional right now. Once you fill in this one file, the same UI
/// will drive your real scooter.
///
/// TIP: the app now has a "Custom Command" screen (terminal icon on the
/// scooter detail screen) that lists every discovered service/characteristic,
/// lets you write raw hex bytes to any of them, and logs every byte the
/// scooter sends back on any characteristic — not just the one this file
/// currently assumes is telemetry. Use it *while* the real Kukirin Manager
/// app is also connected... actually it can only hold one BLE connection at a
/// time, so instead: use this app's Custom Command screen to subscribe to
/// every NOTIFY characteristic, then disconnect, open the real Kukirin app,
/// perform an action (e.g. change mode), reconnect here, and compare what
/// values you read — or better, use a packet capture (see below) which can
/// watch the real app's traffic directly without you needing two apps
/// fighting over one connection.
///
/// PRIOR ART / RESEARCH STARTING POINTS (none of these are Kukirin-specific
/// except the last one, but the *technique* transfers directly):
///   - Xiaomi M365 BLE protocol, fully reverse engineered & documented:
///     https://github.com/CamiAlfa/M365-BLE-PROTOCOL
///     https://github.com/lukaville/mijia-scooter-reverse-engineering
///   - Ninebot BLE/UART protocol reverse engineering:
///     https://github.com/ub4raf/Ninebot-PROTOCOL
///     Forum writeup this and the M365 work are both based on:
///     http://forum.electricunicycle.org/topic/2686-unraveling-ninebot-one-e-ble-protocol-success/
///   - A multi-brand third-party client (currently targets iScooter, built to
///     extend to more brands) with protocol notes from decompiled APKs:
///     https://github.com/johan-perso/escive
///   - A closed-source iOS app that specifically supports the Kukirin G4 exists
///     (https://github.com/maksdoner/ScootX-KuKirinG4-2007-iOS) — its README
///     confirms the G4's BLE protocol *has* been figured out by someone, but
///     the author deliberately keeps the command format unpublished/obfuscated
///     in the binary. Worth knowing the protocol is crackable; not a source of
///     the actual bytes.
///
/// HOW TO FIND KUKIRIN'S SPECIFIC BYTES (nobody has published these publicly
/// as far as I can find):
///   1. Packet capture while using the real Kukirin Manager app (see the
///      Wireshark/HCI-snoop steps above) — this is the most reliable method
///      and doesn't require any reverse engineering skill, just patience.
///   2. Decompile the Kukirin Manager Android APK with a tool like
///      jadx-gui (https://github.com/skylot/jadx) and search the resulting
///      source for `UUID.fromString`, `BluetoothGattCharacteristic`, or
///      `CBUUID` - the service/characteristic UUIDs and the byte-building
///      code for each command are usually easy to spot once decompiled.
///      This kind of interoperability reverse engineering (making your own
///      app talk to your own hardware) is a long-standing, normal practice
///      in the hobbyist scooter/EV community - see every link above - but
///      always check your local laws/the app's terms before doing it.
/// ============================================================================
enum ScooterProtocol {

    // MARK: - GATT identifiers (PLACEHOLDERS — replace with real captured UUIDs)

    /// Service advertised by the scooter's BLE controller.
    static let serviceUUID = CBUUID(string: "0000FFE0-0000-1000-8000-00805F9B34FB")

    /// Characteristic you WRITE commands to (mode change, speed limit, lock, lights...).
    static let commandCharacteristicUUID = CBUUID(string: "0000FFE1-0000-1000-8000-00805F9B34FB")

    /// Characteristic that NOTIFIES you with live telemetry (speed, battery, odometer...).
    static let telemetryCharacteristicUUID = CBUUID(string: "0000FFE2-0000-1000-8000-00805F9B34FB")

    /// Many scooter/e-bike controllers only accept commands from devices whose BLE
    /// advertised name contains a recognizable prefix. Adjust to match what you see
    /// when you scan (this app also lets you connect to ANY nearby device manually).
    static let nameFilterPrefixes = ["KUKIRIN", "KK-", "G2", "M4", "G3"]

    // MARK: - Outgoing commands (PLACEHOLDER encoding)

    /// Builds the raw bytes to write to `commandCharacteristicUUID` to switch ride mode.
    /// PLACEHOLDER FORMAT — replace body once you've captured the real bytes.
    static func encodeSetMode(_ mode: RideMode) -> Data {
        // Example placeholder framing: [0xAA, 0x01, <mode>, checksum]
        var bytes: [UInt8] = [0xAA, 0x01, UInt8(mode.rawValue)]
        bytes.append(checksum(bytes))
        return Data(bytes)
    }

    /// Builds the raw bytes to write to set the max speed limit (km/h) for a given mode.
    /// PLACEHOLDER FORMAT — replace body once you've captured the real bytes.
    static func encodeSetMaxSpeed(_ kmh: Double, for mode: RideMode) -> Data {
        let clamped = max(0, min(kmh, mode.absoluteMaxKmh))
        let speedByte = UInt8(clamped.rounded())
        var bytes: [UInt8] = [0xAA, 0x02, UInt8(mode.rawValue), speedByte]
        bytes.append(checksum(bytes))
        return Data(bytes)
    }

    static func encodeSetLock(_ locked: Bool) -> Data {
        var bytes: [UInt8] = [0xAA, 0x03, locked ? 0x01 : 0x00]
        bytes.append(checksum(bytes))
        return Data(bytes)
    }

    static func encodeSetLights(_ on: Bool) -> Data {
        var bytes: [UInt8] = [0xAA, 0x04, on ? 0x01 : 0x00]
        bytes.append(checksum(bytes))
        return Data(bytes)
    }

    static func encodeSetCruiseControl(_ on: Bool) -> Data {
        var bytes: [UInt8] = [0xAA, 0x05, on ? 0x01 : 0x00]
        bytes.append(checksum(bytes))
        return Data(bytes)
    }

    private static func checksum(_ bytes: [UInt8]) -> UInt8 {
        bytes.reduce(0) { $0 ^ $1 } // placeholder XOR checksum
    }

    // MARK: - Incoming telemetry (PLACEHOLDER decoding)

    /// Parses a telemetry notification payload into a `ScooterTelemetry` struct.
    /// PLACEHOLDER FORMAT — replace body once you've captured the real byte layout.
    /// Returns nil if the payload doesn't look like a telemetry frame.
    static func decodeTelemetry(_ data: Data, previous: ScooterTelemetry) -> ScooterTelemetry? {
        guard data.count >= 8, data.first == 0xAA else { return nil }
        let bytes = [UInt8](data)

        var telemetry = previous
        // Example placeholder layout:
        // [0]=0xAA  [1]=speed*10 (0-255 -> 0-25.5km/h step)  [2]=battery%
        // [3]=mode  [4]=lockFlags  [5..6]=odometer(LE, tens of km) [7]=checksum
        telemetry.speedKmh = Double(bytes[1]) / 10.0
        telemetry.batteryPercent = Int(bytes[2])
        if let mode = RideMode(rawValue: Int(bytes[3])) {
            telemetry.mode = mode
        }
        telemetry.isLocked = (bytes[4] & 0x01) != 0
        telemetry.lightsOn = (bytes[4] & 0x02) != 0
        telemetry.cruiseControlOn = (bytes[4] & 0x04) != 0
        let odometerRaw = UInt16(bytes[5]) | (UInt16(bytes[6]) << 8)
        telemetry.odometerKm = Double(odometerRaw) / 10.0
        return telemetry
    }
}
