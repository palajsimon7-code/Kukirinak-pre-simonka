import SwiftUI
import CoreBluetooth

struct CustomCommandView: View {
    @EnvironmentObject var ble: BLEManager
    @ObservedObject var scooter: Scooter

    @State private var selectedCharacteristic: CBCharacteristic?
    @State private var hexInput: String = "AA 01 00"
    @State private var sendResult: String?

    var body: some View {
        VStack(spacing: 0) {
            if scooter.isDemo || ble.demoModeEnabled {
                demoNotice
            } else {
                characteristicPicker
                sendBar
                Divider().overlay(Theme.textSecondary.opacity(0.15))
                logView
            }
        }
        .background(Theme.backgroundGradient.ignoresSafeArea())
        .navigationTitle("Custom Command")
        .navigationBarTitleDisplayMode(.inline)
    }

    private var demoNotice: some View {
        VStack(spacing: 12) {
            Spacer()
            Image(systemName: "terminal")
                .font(.system(size: 40))
                .foregroundColor(Theme.textSecondary)
            Text("Not available in Demo Mode")
                .font(.headline)
                .foregroundColor(Theme.textPrimary)
            Text("Connect to a real scooter over Bluetooth to send raw commands and inspect its services/characteristics.")
                .font(.subheadline)
                .foregroundColor(Theme.textSecondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 40)
            Spacer()
        }
    }

    private var characteristicPicker: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(ble.connectedServices, id: \.uuid) { service in
                    ForEach(service.characteristics ?? [], id: \.uuid) { characteristic in
                        CharacteristicChip(
                            characteristic: characteristic,
                            isSelected: selectedCharacteristic?.uuid == characteristic.uuid
                        )
                        .onTapGesture {
                            selectedCharacteristic = characteristic
                            if characteristic.properties.contains(.notify) {
                                ble.subscribe(to: characteristic)
                            }
                        }
                    }
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
        }
        .onAppear {
            if selectedCharacteristic == nil {
                selectedCharacteristic = ble.connectedServices
                    .flatMap { $0.characteristics ?? [] }
                    .first(where: { $0.properties.contains(.write) || $0.properties.contains(.writeWithoutResponse) })
            }
        }
    }

    private var sendBar: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Hex bytes to write, e.g. \"AA 01 02\"")
                .font(.caption)
                .foregroundColor(Theme.textSecondary)
            HStack(spacing: 10) {
                TextField("AA 01 02", text: $hexInput)
                    .font(.system(.body, design: .monospaced))
                    .autocapitalization(.allCharacters)
                    .disableAutocorrection(true)
                    .padding(10)
                    .background(RoundedRectangle(cornerRadius: 10).fill(Theme.cardBackgroundLight))
                    .foregroundColor(Theme.textPrimary)

                Button {
                    send()
                } label: {
                    Image(systemName: "paperplane.fill")
                        .font(.body.weight(.semibold))
                        .foregroundColor(.black)
                        .padding(12)
                        .background(Circle().fill(selectedCharacteristic == nil ? AnyShapeStyle(Theme.textSecondary) : AnyShapeStyle(Theme.accentGradient)))
                }
                .disabled(selectedCharacteristic == nil)
            }
            if let result = sendResult {
                Text(result)
                    .font(.caption)
                    .foregroundColor(Theme.textSecondary)
            }
        }
        .padding(.horizontal, 16)
        .padding(.bottom, 10)
    }

    private var logView: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 6) {
                    if ble.log.isEmpty {
                        Text("No traffic yet. Send a command, or subscribe to a NOTIFY characteristic above and use the real Kukirin Manager app / scooter controls to see what it sends.")
                            .font(.caption)
                            .foregroundColor(Theme.textSecondary)
                            .padding(.top, 20)
                            .padding(.horizontal, 4)
                    }
                    ForEach(ble.log) { entry in
                        LogRow(entry: entry)
                            .id(entry.id)
                    }
                }
                .padding(16)
            }
            .onChange(of: ble.log.count) { _ in
                if let last = ble.log.last { withAnimation { proxy.scrollTo(last.id, anchor: .bottom) } }
            }
        }
    }

    private func send() {
        guard let characteristic = selectedCharacteristic else { return }
        let ok = ble.sendRawCommand(hex: hexInput, to: characteristic)
        sendResult = ok ? nil : "Couldn't parse those bytes - use hex like \"AA 01 02\"."
    }
}

private struct CharacteristicChip: View {
    let characteristic: CBCharacteristic
    let isSelected: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(characteristic.uuid.uuidString)
                .font(.system(size: 11, weight: .semibold, design: .monospaced))
                .lineLimit(1)
            Text(propertySummary)
                .font(.system(size: 10))
                .opacity(0.7)
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 8)
        .foregroundColor(isSelected ? .black : Theme.textPrimary)
        .background(
            RoundedRectangle(cornerRadius: 10)
                .fill(isSelected ? AnyShapeStyle(Theme.accentGradient) : AnyShapeStyle(Theme.cardBackgroundLight))
        )
    }

    private var propertySummary: String {
        var parts: [String] = []
        if characteristic.properties.contains(.write) { parts.append("WRITE") }
        if characteristic.properties.contains(.writeWithoutResponse) { parts.append("WRITE-NR") }
        if characteristic.properties.contains(.read) { parts.append("READ") }
        if characteristic.properties.contains(.notify) { parts.append("NOTIFY") }
        return parts.joined(separator: " · ")
    }
}

private struct LogRow: View {
    let entry: BLELogEntry

    var body: some View {
        HStack(alignment: .top, spacing: 8) {
            Text(entry.direction.rawValue)
                .font(.system(size: 10, weight: .heavy, design: .monospaced))
                .foregroundColor(entry.direction == .sent ? Theme.accentSecondary : Theme.accent)
                .frame(width: 36, alignment: .leading)
            VStack(alignment: .leading, spacing: 2) {
                Text(entry.hex)
                    .font(.system(size: 13, weight: .medium, design: .monospaced))
                    .foregroundColor(Theme.textPrimary)
                Text("\(shortUUID(entry.characteristicUUID))  ·  \(timeString(entry.timestamp))")
                    .font(.system(size: 10))
                    .foregroundColor(Theme.textSecondary)
            }
            Spacer()
        }
        .padding(.vertical, 4)
    }

    private func shortUUID(_ uuid: String) -> String {
        uuid.count > 8 ? String(uuid.prefix(8)) + "…" : uuid
    }

    private func timeString(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm:ss.SSS"
        return formatter.string(from: date)
    }
}
