import SwiftUI

struct StatTile: View {
    let icon: String
    let title: String
    let value: String
    var tint: Color = Theme.accent

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Image(systemName: icon)
                .font(.system(size: 16, weight: .semibold))
                .foregroundColor(tint)
            Text(value)
                .font(.title3.bold())
                .foregroundColor(Theme.textPrimary)
                .lineLimit(1)
                .minimumScaleFactor(0.7)
            Text(title)
                .font(.caption)
                .foregroundColor(Theme.textSecondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .cardStyle()
    }
}

struct ToggleRow: View {
    let icon: String
    let title: String
    @Binding var isOn: Bool

    var body: some View {
        HStack {
            Image(systemName: icon)
                .font(.system(size: 16, weight: .semibold))
                .foregroundColor(Theme.accent)
                .frame(width: 24)
            Text(title)
                .foregroundColor(Theme.textPrimary)
                .font(.body.weight(.medium))
            Spacer()
            Toggle("", isOn: $isOn).labelsHidden().tint(Theme.accent)
        }
        .padding(.vertical, 6)
    }
}
