import SwiftUI

struct ModeSelectorView: View {
    @Binding var selected: RideMode
    var onChange: (RideMode) -> Void

    var body: some View {
        HStack(spacing: 8) {
            ForEach(RideMode.allCases) { mode in
                Button {
                    selected = mode
                    onChange(mode)
                } label: {
                    VStack(spacing: 6) {
                        Image(systemName: mode.symbol)
                            .font(.system(size: 18, weight: .semibold))
                        Text(mode.title)
                            .font(.footnote.weight(.semibold))
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                    .foregroundColor(selected == mode ? .black : Theme.textSecondary)
                    .background(
                        RoundedRectangle(cornerRadius: 14, style: .continuous)
                            .fill(selected == mode ? AnyShapeStyle(Theme.accentGradient) : AnyShapeStyle(Theme.cardBackgroundLight))
                    )
                }
                .buttonStyle(.plain)
            }
        }
    }
}
