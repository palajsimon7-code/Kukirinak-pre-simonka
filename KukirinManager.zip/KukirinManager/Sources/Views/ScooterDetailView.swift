import SwiftUI

struct ScooterDetailView: View {
    @EnvironmentObject var ble: BLEManager
    @ObservedObject var scooter: Scooter
    @State private var showSettings = false

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                header

                SpeedGaugeView(
                    speedKmh: scooter.telemetry.speedKmh,
                    maxKmh: scooter.limits.value(for: scooter.telemetry.mode)
                )
                .padding(.top, 8)

                ModeSelectorView(
                    selected: Binding(
                        get: { scooter.telemetry.mode },
                        set: { _ in }
                    ),
                    onChange: { ble.setMode($0) }
                )

                statGrid

                controlsCard

                maxSpeedCard

                customCommandLink

                if scooter.isDemo || ble.demoModeEnabled {
                    Label("Demo Mode — showing simulated data", systemImage: "wand.and.stars")
                        .font(.caption)
                        .foregroundColor(Theme.textSecondary)
                }
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 30)
        }
        .navigationBarBackButtonHidden(true)
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
                Button {
                    ble.disconnect()
                } label: {
                    Image(systemName: "chevron.left").foregroundColor(Theme.textPrimary)
                }
            }
            ToolbarItem(placement: .navigationBarTrailing) {
                NavigationLink {
                    CustomCommandView(scooter: scooter)
                } label: {
                    Image(systemName: "terminal").foregroundColor(Theme.textPrimary)
                }
            }
        }
    }

    private var header: some View {
        VStack(spacing: 4) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text(scooter.name)
                        .font(.title3.bold())
                        .foregroundColor(Theme.textPrimary)
                    HStack(spacing: 5) {
                        Circle().fill(Theme.accent).frame(width: 7, height: 7)
                        Text("Connected")
                            .font(.caption)
                            .foregroundColor(Theme.textSecondary)
                    }
                }
                Spacer()
                Image(systemName: "scooter")
                    .font(.system(size: 30))
                    .foregroundStyle(Theme.accentGradient)
            }
        }
        .padding(.top, 8)
    }

    private var statGrid: some View {
        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
            StatTile(icon: "battery.75", title: "Battery", value: "\(scooter.telemetry.batteryPercent)%",
                      tint: batteryColor)
            StatTile(icon: "speedometer", title: "Mode", value: scooter.telemetry.mode.title)
            StatTile(icon: "road.lanes", title: "Odometer", value: String(format: "%.1f km", scooter.telemetry.odometerKm))
            StatTile(icon: "location.circle", title: "Trip", value: String(format: "%.2f km", scooter.telemetry.tripKm))
        }
    }

    private var batteryColor: Color {
        switch scooter.telemetry.batteryPercent {
        case ..<20: return Theme.danger
        case 20..<50: return Theme.warning
        default: return Theme.accent
        }
    }

    private var controlsCard: some View {
        VStack(spacing: 2) {
            ToggleRow(icon: "lock.fill", title: "Lock scooter", isOn: Binding(
                get: { scooter.telemetry.isLocked },
                set: { ble.setLocked($0) }
            ))
            Divider().overlay(Theme.textSecondary.opacity(0.15))
            ToggleRow(icon: "headlight.high.beam.fill", title: "Lights", isOn: Binding(
                get: { scooter.telemetry.lightsOn },
                set: { ble.setLights($0) }
            ))
            Divider().overlay(Theme.textSecondary.opacity(0.15))
            ToggleRow(icon: "point.topleft.down.curvedto.point.bottomright.up", title: "Cruise control", isOn: Binding(
                get: { scooter.telemetry.cruiseControlOn },
                set: { ble.setCruiseControl($0) }
            ))
        }
        .cardStyle()
    }

    private var customCommandLink: some View {
        NavigationLink {
            CustomCommandView(scooter: scooter)
        } label: {
            HStack(spacing: 12) {
                Image(systemName: "terminal.fill")
                    .foregroundColor(Theme.accentSecondary)
                VStack(alignment: .leading, spacing: 2) {
                    Text("Custom Command")
                        .font(.subheadline.weight(.semibold))
                        .foregroundColor(Theme.textPrimary)
                    Text("Send raw BLE bytes & watch responses live")
                        .font(.caption)
                        .foregroundColor(Theme.textSecondary)
                }
                Spacer()
                Image(systemName: "chevron.right")
                    .font(.footnote.weight(.semibold))
                    .foregroundColor(Theme.textSecondary)
            }
            .cardStyle()
        }
        .buttonStyle(.plain)
    }

    private var maxSpeedCard: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Max speed per mode")
                .font(.headline)
                .foregroundColor(Theme.textPrimary)

            ForEach(RideMode.allCases) { mode in
                VStack(alignment: .leading, spacing: 6) {
                    HStack {
                        Label(mode.title, systemImage: mode.symbol)
                            .font(.subheadline.weight(.semibold))
                            .foregroundColor(Theme.textPrimary)
                        Spacer()
                        Text("\(Int(scooter.limits.value(for: mode))) km/h")
                            .font(.subheadline.weight(.semibold))
                            .foregroundColor(Theme.accent)
                    }
                    Slider(
                        value: Binding(
                            get: { scooter.limits.value(for: mode) },
                            set: { ble.setMaxSpeed($0, for: mode) }
                        ),
                        in: 5...mode.absoluteMaxKmh,
                        step: 1
                    )
                    .tint(Theme.accent)
                }
            }
        }
        .cardStyle()
    }
}
