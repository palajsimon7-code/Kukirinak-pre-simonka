import SwiftUI

struct RootView: View {
    @EnvironmentObject var ble: BLEManager

    var body: some View {
        NavigationStack {
            Group {
                if let scooter = ble.connected, scooter.connectionState == .connected {
                    ScooterDetailView(scooter: scooter)
                } else {
                    ScannerView()
                }
            }
            .background(Theme.backgroundGradient.ignoresSafeArea())
        }
        .tint(Theme.accent)
    }
}

struct ScannerView: View {
    @EnvironmentObject var ble: BLEManager
    @State private var showSettings = false

    var body: some View {
        VStack(spacing: 0) {
            header

            if let scooter = ble.connected, scooter.connectionState == .connecting {
                connectingBanner(scooter)
            }

            if !ble.isBluetoothOn && !ble.demoModeEnabled {
                bluetoothOffState
            } else if ble.discovered.isEmpty && !ble.demoModeEnabled {
                emptyState
            } else {
                deviceList
            }

            Spacer(minLength: 0)
            footer
        }
        .onAppear { if !ble.demoModeEnabled { ble.startScan() } }
        .onDisappear { ble.stopScan() }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Image(systemName: "bolt.circle.fill")
                    .font(.system(size: 28))
                    .foregroundStyle(Theme.accentGradient)
                Text("Kukirin Manager")
                    .font(.title2.bold())
                    .foregroundColor(Theme.textPrimary)
                Spacer()
                Toggle("", isOn: $ble.demoModeEnabled)
                    .labelsHidden()
                    .tint(Theme.accent)
            }
            HStack {
                Text(ble.demoModeEnabled ? "Demo Mode" : (ble.isScanning ? "Scanning for scooters…" : "Nearby scooters"))
                    .font(.subheadline)
                    .foregroundColor(Theme.textSecondary)
                Spacer()
                if ble.isScanning {
                    ProgressView().scaleEffect(0.7)
                }
            }
        }
        .padding(.horizontal, 20)
        .padding(.top, 16)
        .padding(.bottom, 12)
    }

    private var bluetoothOffState: some View {
        VStack(spacing: 14) {
            Spacer()
            Image(systemName: "bluetooth.slash")
                .font(.system(size: 46))
                .foregroundColor(Theme.textSecondary)
            Text("Bluetooth is off")
                .font(.headline)
                .foregroundColor(Theme.textPrimary)
            Text("Turn on Bluetooth to find nearby Kukirin scooters, or try Demo Mode above.")
                .font(.subheadline)
                .foregroundColor(Theme.textSecondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 40)
            Spacer()
        }
    }

    private var emptyState: some View {
        VStack(spacing: 14) {
            Spacer()
            Image(systemName: "scooter")
                .font(.system(size: 46))
                .foregroundColor(Theme.textSecondary)
            Text("No scooters found yet")
                .font(.headline)
                .foregroundColor(Theme.textPrimary)
            Text("Make sure your scooter is powered on and within range.")
                .font(.subheadline)
                .foregroundColor(Theme.textSecondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 40)
            Spacer()
        }
    }

    private var deviceList: some View {
        ScrollView {
            LazyVStack(spacing: 12) {
                if ble.demoModeEnabled {
                    DeviceRow(scooter: ble.makeDemoScooter())
                }
                ForEach(ble.discovered) { scooter in
                    DeviceRow(scooter: scooter)
                }
            }
            .padding(.horizontal, 20)
            .padding(.top, 4)
        }
    }

    private func connectingBanner(_ scooter: Scooter) -> some View {
        HStack(spacing: 10) {
            ProgressView().tint(Theme.accent)
            Text("Connecting to \(scooter.name)…")
                .foregroundColor(Theme.textPrimary)
                .font(.subheadline.weight(.medium))
            Spacer()
        }
        .padding(14)
        .background(RoundedRectangle(cornerRadius: 14).fill(Theme.cardBackground))
        .padding(.horizontal, 20)
        .padding(.bottom, 8)
    }

    private var footer: some View {
        Text(ble.demoModeEnabled ? "Simulated data — great for trying out the app." : "Tap a scooter to connect via Bluetooth.")
            .font(.caption)
            .foregroundColor(Theme.textSecondary)
            .padding(.bottom, 18)
    }
}

private struct DeviceRow: View {
    @EnvironmentObject var ble: BLEManager
    @ObservedObject var scooter: Scooter

    var body: some View {
        Button {
            ble.connect(scooter)
        } label: {
            HStack(spacing: 14) {
                ZStack {
                    Circle().fill(brandColor.opacity(0.18)).frame(width: 50, height: 50)
                    Image(systemName: scooter.brand.symbolName)
                        .font(.system(size: 22))
                        .foregroundColor(brandColor)
                }
                VStack(alignment: .leading, spacing: 3) {
                    Text(scooter.name)
                        .font(.body.weight(.semibold))
                        .foregroundColor(Theme.textPrimary)
                    HStack(spacing: 6) {
                        Text(scooter.brand.displayName)
                            .font(.caption.weight(.semibold))
                            .foregroundColor(brandColor)
                        Text("·")
                            .foregroundColor(Theme.textSecondary)
                        Image(systemName: signalIcon)
                            .font(.caption2)
                        Text(scooter.isDemo ? "Simulated" : "\(scooter.rssi) dBm")
                            .font(.caption)
                    }
                    .foregroundColor(Theme.textSecondary)
                }
                Spacer()
                Image(systemName: "chevron.right")
                    .font(.footnote.weight(.semibold))
                    .foregroundColor(Theme.textSecondary)
            }
            .cardStyle()
        }
        .buttonStyle(.plain)
    }

    private var brandColor: Color {
        let t = scooter.brand.tint
        return Color(red: t.0, green: t.1, blue: t.2)
    }

    private var signalIcon: String {
        if scooter.isDemo { return "waveform" }
        switch scooter.rssi {
        case -50...0: return "wifi"
        case -70 ..< -50: return "wifi"
        default: return "wifi.exclamationmark"
        }
    }
}
