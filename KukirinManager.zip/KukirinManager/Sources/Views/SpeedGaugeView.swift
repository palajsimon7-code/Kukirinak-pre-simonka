import SwiftUI

struct SpeedGaugeView: View {
    let speedKmh: Double
    let maxKmh: Double

    private var progress: Double {
        guard maxKmh > 0 else { return 0 }
        return min(max(speedKmh / maxKmh, 0), 1)
    }

    var body: some View {
        ZStack {
            Circle()
                .stroke(Theme.cardBackgroundLight, lineWidth: 18)

            Circle()
                .trim(from: 0, to: progress * 0.75)
                .stroke(
                    Theme.accentGradient,
                    style: StrokeStyle(lineWidth: 18, lineCap: .round)
                )
                .rotationEffect(.degrees(135))
                .animation(.easeOut(duration: 0.35), value: progress)

            VStack(spacing: 2) {
                Text(String(format: "%.0f", speedKmh))
                    .font(.system(size: 56, weight: .bold, design: .rounded))
                    .foregroundColor(Theme.textPrimary)
                    .contentTransition(.numericText())
                    .animation(.easeOut(duration: 0.25), value: speedKmh)
                Text("km/h")
                    .font(.subheadline.weight(.medium))
                    .foregroundColor(Theme.textSecondary)
            }
        }
        .rotationEffect(.degrees(0))
        .frame(width: 220, height: 220)
    }
}
